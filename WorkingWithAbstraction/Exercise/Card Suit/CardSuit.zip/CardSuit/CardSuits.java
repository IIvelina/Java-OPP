package Exercise.CardSuit;

public enum CardSuits {
    CLUBS, //пика //0
    DIAMONDS, //каро //1
    HEARTS, //купа //2
    SPADES; //спатия //3

}
