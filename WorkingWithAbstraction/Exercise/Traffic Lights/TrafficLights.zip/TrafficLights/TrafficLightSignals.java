package TrafficLights;

public enum TrafficLightSignals {
    RED,
    YELLOW,
    GREEN;
}
