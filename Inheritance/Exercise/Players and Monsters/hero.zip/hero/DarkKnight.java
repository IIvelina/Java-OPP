package hero;

public class DarkKnight extends Knight{
    public DarkKnight(String username, int level) {
        super(username, level);
    }
}
